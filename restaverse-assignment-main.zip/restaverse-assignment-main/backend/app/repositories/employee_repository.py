"""
Employee repository — data access layer.

This layer is the ONLY place where database queries are constructed.
All queries use SQLAlchemy ORM, which parameterizes inputs automatically,
preventing SQL injection.

The repository pattern decouples business logic from data access,
making the service layer testable with mock repositories.
"""

import logging
from sqlalchemy import func, or_
from sqlalchemy.orm import Session

from app.models.employee import Employee
from app.schemas.employee import SortField, SortOrder

logger = logging.getLogger(__name__)

# Mapping from sort field enum to model attribute
SORT_FIELD_MAP = {
    SortField.NAME: Employee.name,
    SortField.DEPARTMENT: Employee.department,
    SortField.DESIGNATION: Employee.designation,
    SortField.DATE_OF_JOINING: Employee.date_of_joining,
}


class EmployeeRepository:
    """Handles all database operations for the Employee entity."""

    def __init__(self, db: Session):
        self.db = db

    def search(
        self,
        search_term: str | None = None,
        department: str | None = None,
        sort_by: SortField = SortField.NAME,
        sort_order: SortOrder = SortOrder.ASC,
        offset: int = 0,
        limit: int = 20,
    ) -> list[Employee]:
        """
        Search employees with optional filters, sorting, and pagination.

        Uses LIKE with parameterized queries (SQL injection safe).
        The ORM generates: WHERE name LIKE :name_1 OR department LIKE :dept_1
        """
        query = self.db.query(Employee)
        query = self._apply_filters(query, search_term, department)
        query = self._apply_sorting(query, sort_by, sort_order)

        return query.offset(offset).limit(limit).all()

    def count(
        self,
        search_term: str | None = None,
        department: str | None = None,
    ) -> int:
        """Count total matching employees for pagination metadata."""
        query = self.db.query(func.count(Employee.id))
        query = self._apply_filters(query, search_term, department)
        return query.scalar() or 0

    def get_distinct_departments(self) -> list[str]:
        """Return all unique department names, sorted alphabetically."""
        results = (
            self.db.query(Employee.department)
            .distinct()
            .order_by(Employee.department)
            .all()
        )
        return [row[0] for row in results]

    def get_by_id(self, employee_id: int) -> Employee | None:
        """Fetch a single employee by ID."""
        return self.db.query(Employee).filter(Employee.id == employee_id).first()

    def _apply_filters(self, query, search_term: str | None, department: str | None):
        """
        Apply search and department filters to the query.

        Search is performed as case-insensitive partial match on both
        name and department columns using OR logic.
        """
        if search_term:
            search_pattern = f"%{search_term}%"
            query = query.filter(
                or_(
                    Employee.name.ilike(search_pattern),
                    Employee.department.ilike(search_pattern),
                )
            )

        if department:
            query = query.filter(Employee.department == department)

        return query

    def _apply_sorting(self, query, sort_by: SortField, sort_order: SortOrder):
        """Apply sorting to the query using the sort field map."""
        column = SORT_FIELD_MAP.get(sort_by, Employee.name)

        if sort_order == SortOrder.DESC:
            query = query.order_by(column.desc())
        else:
            query = query.order_by(column.asc())

        return query
