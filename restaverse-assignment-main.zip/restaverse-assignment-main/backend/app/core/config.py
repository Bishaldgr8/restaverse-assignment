"""
Application configuration module.

Uses pydantic-settings to load and validate environment variables at startup.
Fails fast if required configuration is missing.

Database Strategy:
  By default the application connects to MySQL. Set USE_SQLITE=true in .env
  (or as an environment variable) to use a local SQLite file instead — useful
  for development or environments where MySQL is unavailable.
"""

from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Application settings loaded from environment variables."""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
    )

    # Application
    APP_NAME: str = "Employee Directory API"
    APP_VERSION: str = "1.0.0"
    DEBUG: bool = False

    # Database – set USE_SQLITE=true to bypass MySQL entirely
    USE_SQLITE: bool = False
    SQLITE_PATH: str = "./employee_directory.db"

    DB_HOST: str = "localhost"
    DB_PORT: int = 3306
    DB_USER: str = "root"
    DB_PASSWORD: str = "password"
    DB_NAME: str = "employee_directory"

    # Connection Pool (ignored when USE_SQLITE=true)
    DB_POOL_SIZE: int = 10
    DB_MAX_OVERFLOW: int = 20
    DB_POOL_RECYCLE: int = 3600
    DB_POOL_PRE_PING: bool = True

    # CORS
    CORS_ORIGINS: str = "http://localhost:3000,http://localhost:5173"

    # Pagination defaults
    DEFAULT_PAGE_SIZE: int = 20
    MAX_PAGE_SIZE: int = 100

    @property
    def DATABASE_URL(self) -> str:
        """Return the active database URL (SQLite or MySQL)."""
        if self.USE_SQLITE:
            return f"sqlite:///{self.SQLITE_PATH}"
        return (
            f"mysql+pymysql://{self.DB_USER}:{self.DB_PASSWORD}"
            f"@{self.DB_HOST}:{self.DB_PORT}/{self.DB_NAME}"
            f"?charset=utf8mb4"
        )

    @property
    def cors_origins_list(self) -> list[str]:
        """Parse CORS origins from comma-separated string."""
        return [origin.strip() for origin in self.CORS_ORIGINS.split(",")]


@lru_cache()
def get_settings() -> Settings:
    """
    Cached settings instance.

    Using lru_cache ensures we only parse env vars once,
    and the same Settings object is reused across the application.
    """
    return Settings()
