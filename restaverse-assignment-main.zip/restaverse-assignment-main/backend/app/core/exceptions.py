"""
Centralized exception handling.

Custom exceptions are caught by handlers registered on the FastAPI app,
ensuring consistent error responses and preventing internal details from leaking.
"""

import logging
from fastapi import FastAPI, Request, status
from fastapi.responses import JSONResponse

logger = logging.getLogger(__name__)


# ─── Custom Exceptions ──────────────────────────────────────────────────────

class AppException(Exception):
    """Base exception for all application errors."""

    def __init__(self, message: str, status_code: int = 500):
        self.message = message
        self.status_code = status_code
        super().__init__(self.message)


class NotFoundException(AppException):
    """Resource not found."""

    def __init__(self, message: str = "Resource not found"):
        super().__init__(message=message, status_code=status.HTTP_404_NOT_FOUND)


class ValidationException(AppException):
    """Input validation failed."""

    def __init__(self, message: str = "Validation error"):
        super().__init__(message=message, status_code=status.HTTP_422_UNPROCESSABLE_ENTITY)


class DatabaseException(AppException):
    """Database operation failed."""

    def __init__(self, message: str = "A database error occurred"):
        super().__init__(message=message, status_code=status.HTTP_503_SERVICE_UNAVAILABLE)


# ─── Exception Handlers ─────────────────────────────────────────────────────

def register_exception_handlers(app: FastAPI) -> None:
    """Register all custom exception handlers on the FastAPI application."""

    @app.exception_handler(AppException)
    async def app_exception_handler(request: Request, exc: AppException) -> JSONResponse:
        """Handle all custom application exceptions."""
        logger.warning(
            "AppException: %s | Path: %s | Status: %d",
            exc.message,
            request.url.path,
            exc.status_code,
        )
        return JSONResponse(
            status_code=exc.status_code,
            content={
                "success": False,
                "message": exc.message,
                "data": None,
            },
        )

    @app.exception_handler(Exception)
    async def unhandled_exception_handler(request: Request, exc: Exception) -> JSONResponse:
        """
        Catch-all for unhandled exceptions.
        
        Logs the full traceback for debugging but returns a generic message
        to the client, preventing internal details from leaking.
        """
        logger.exception(
            "Unhandled exception at %s: %s",
            request.url.path,
            str(exc),
        )
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={
                "success": False,
                "message": "An unexpected error occurred. Please try again later.",
                "data": None,
            },
        )
