"""
Dependency injection for FastAPI routes.

Dependencies are injected via FastAPI's Depends() mechanism,
providing loose coupling between layers. This makes the service
layer easily testable by swapping the repository with a mock.
"""

from fastapi import Depends
from sqlalchemy.orm import Session

from app.database.session import get_db
from app.repositories.employee_repository import EmployeeRepository
from app.services.employee_service import EmployeeService


def get_employee_repository(db: Session = Depends(get_db)) -> EmployeeRepository:
    """Provide an EmployeeRepository instance with a database session."""
    return EmployeeRepository(db)


def get_employee_service(
    repository: EmployeeRepository = Depends(get_employee_repository),
) -> EmployeeService:
    """Provide an EmployeeService instance with its repository dependency."""
    return EmployeeService(repository)
