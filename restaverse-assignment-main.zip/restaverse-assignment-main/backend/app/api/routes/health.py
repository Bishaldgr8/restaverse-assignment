"""
Health check route for monitoring and container orchestration.
"""

from fastapi import APIRouter
from sqlalchemy import text

from app.database.session import SessionLocal
from app.core.config import get_settings
from app.schemas.employee import HealthResponse

router = APIRouter(tags=["Health"])
settings = get_settings()


@router.get(
    "/health",
    response_model=HealthResponse,
    summary="Health check",
    description="Check application and database health.",
)
async def health_check() -> HealthResponse:
    """Verify the application and database are healthy."""
    db_status = "healthy"

    try:
        db = SessionLocal()
        db.execute(text("SELECT 1"))
        db.close()
    except Exception:
        db_status = "unhealthy"

    return HealthResponse(
        status="healthy" if db_status == "healthy" else "degraded",
        database=db_status,
        version=settings.APP_VERSION,
    )
