"""
Employee API routes.

These route handlers are intentionally thin — they handle only HTTP concerns
(parsing query params, returning status codes). All business logic lives
in the EmployeeService layer.
"""

from fastapi import APIRouter, Depends, Query

from app.api.dependencies import get_employee_service
from app.schemas.employee import (
    DepartmentListResponse,
    EmployeeResponse,
    PaginatedEmployeeResponse,
    SortField,
    SortOrder,
)
from app.services.employee_service import EmployeeService

router = APIRouter(prefix="/employees", tags=["Employees"])


@router.get(
    "",
    response_model=PaginatedEmployeeResponse,
    summary="Search employees",
    description=(
        "Search employees by name or department with pagination and sorting. "
        "Supports partial matching (e.g., 'rah' matches 'Rahul')."
    ),
)
async def search_employees(
    search: str | None = Query(
        default=None,
        min_length=0,
        max_length=100,
        description="Search term to filter by name or department",
    ),
    department: str | None = Query(
        default=None,
        max_length=50,
        description="Filter by exact department name",
    ),
    page: int = Query(
        default=1,
        ge=1,
        le=10000,
        description="Page number (1-indexed)",
    ),
    limit: int = Query(
        default=20,
        ge=1,
        le=100,
        description="Number of results per page",
    ),
    sort_by: SortField = Query(
        default=SortField.NAME,
        description="Field to sort by",
    ),
    sort_order: SortOrder = Query(
        default=SortOrder.ASC,
        description="Sort direction",
    ),
    service: EmployeeService = Depends(get_employee_service),
) -> PaginatedEmployeeResponse:
    """Search employees with optional filters, pagination, and sorting."""
    return service.search_employees(
        search=search,
        department=department,
        page=page,
        limit=limit,
        sort_by=sort_by,
        sort_order=sort_order,
    )


@router.get(
    "/departments",
    response_model=DepartmentListResponse,
    summary="List all departments",
    description="Returns a list of all unique department names.",
)
async def list_departments(
    service: EmployeeService = Depends(get_employee_service),
) -> DepartmentListResponse:
    """Get all unique departments for the filter dropdown."""
    departments = service.get_departments()
    return DepartmentListResponse(data=departments)


@router.get(
    "/{employee_id}",
    response_model=EmployeeResponse,
    summary="Get employee by ID",
    description="Retrieve a single employee by their unique ID.",
)
async def get_employee(
    employee_id: int,
    service: EmployeeService = Depends(get_employee_service),
) -> EmployeeResponse:
    """Get a single employee by ID."""
    return service.get_employee_by_id(employee_id)
