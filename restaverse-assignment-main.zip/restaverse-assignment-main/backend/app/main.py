"""
FastAPI application factory.

Creates and configures the FastAPI application with:
- CORS middleware for cross-origin requests
- Centralized exception handlers
- API route registration under /api/v1 prefix
- Lifespan events for database initialization and seeding
"""

import logging
from contextlib import asynccontextmanager
from collections.abc import AsyncGenerator

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.core.config import get_settings
from app.core.exceptions import register_exception_handlers
from app.database.base import Base
from app.database.session import engine, SessionLocal
from app.api.routes import employees, health
from app.utils.seeder import seed_database

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger(__name__)

settings = get_settings()


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
    """
    Application lifespan manager.
    
    On startup: creates database tables and seeds sample data.
    On shutdown: disposes the database engine (returns all pooled connections).
    """
    logger.info("Starting %s v%s", settings.APP_NAME, settings.APP_VERSION)

    # Create tables if they don't exist
    Base.metadata.create_all(bind=engine)
    logger.info("Database tables created/verified.")

    # Seed sample data
    db = SessionLocal()
    try:
        seed_database(db)
    except Exception as e:
        logger.error("Failed to seed database: %s", str(e))
    finally:
        db.close()

    yield

    # Shutdown
    engine.dispose()
    logger.info("Database connections closed. Application shutdown complete.")


def create_app() -> FastAPI:
    """Create and configure the FastAPI application."""
    app = FastAPI(
        title=settings.APP_NAME,
        version=settings.APP_VERSION,
        description=(
            "A high-performance Employee Directory Search API with pagination, "
            "sorting, and filtering capabilities."
        ),
        docs_url="/api/docs",
        redoc_url="/api/redoc",
        openapi_url="/api/openapi.json",
        lifespan=lifespan,
    )

    # CORS middleware
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origins_list,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Register exception handlers
    register_exception_handlers(app)

    # Register routes
    app.include_router(health.router, prefix="/api/v1")
    app.include_router(employees.router, prefix="/api/v1")

    return app


# Application instance used by uvicorn
app = create_app()
