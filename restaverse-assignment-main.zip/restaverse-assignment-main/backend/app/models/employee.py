"""
Employee SQLAlchemy ORM model.

Indexes:
────────
- idx_employee_name: B-tree index on `name` column.
  Speeds up `WHERE name LIKE 'rahul%'` (prefix search) from O(n) full table
  scan to O(log n) index range scan.

- idx_employee_department: B-tree index on `department` column.
  Enables fast filtering by department without scanning all rows.

- idx_employee_name_dept: Composite index on (name, department).
  Covers the most common search pattern where both fields are filtered.
  The database can satisfy the query entirely from the index (covering index)
  without accessing the table data pages.
"""

from datetime import date, datetime
from sqlalchemy import String, Date, DateTime, Index, func
from sqlalchemy.orm import Mapped, mapped_column

from app.database.base import Base


class Employee(Base):
    """Employee entity representing a company team member."""

    __tablename__ = "employees"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    email: Mapped[str] = mapped_column(String(150), nullable=False, unique=True)
    department: Mapped[str] = mapped_column(String(50), nullable=False)
    designation: Mapped[str] = mapped_column(String(100), nullable=False)
    date_of_joining: Mapped[date] = mapped_column(Date, nullable=False)
    created_at: Mapped[datetime] = mapped_column(
        DateTime, server_default=func.now(), nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, server_default=func.now(), onupdate=func.now(), nullable=False
    )

    __table_args__ = (
        Index("idx_employee_name", "name"),
        Index("idx_employee_department", "department"),
        Index("idx_employee_name_dept", "name", "department"),
    )

    def __repr__(self) -> str:
        return f"<Employee(id={self.id}, name='{self.name}', department='{self.department}')>"
