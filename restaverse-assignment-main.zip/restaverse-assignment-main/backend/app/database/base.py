"""
SQLAlchemy declarative base.

All ORM models inherit from this Base class.
Separated into its own module to avoid circular imports.
"""

from sqlalchemy.orm import DeclarativeBase


class Base(DeclarativeBase):
    """Base class for all SQLAlchemy ORM models."""
    pass
