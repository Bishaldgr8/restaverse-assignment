"""
Database session and engine configuration.

Uses SQLAlchemy's connection pooling for efficient database connections.

Why Connection Pooling?
──────────────────────
1. Creating a new MySQL connection involves TCP handshake, authentication,
   and SSL negotiation (~50-100ms). Pooling eliminates this per-request cost.
2. A pool of pre-established connections is maintained and reused across requests.
3. Under load, the pool grows up to `max_overflow` additional connections,
   then queues requests until a connection is available.
4. `pool_pre_ping` validates connections before use, automatically replacing
   stale connections that MySQL may have closed due to `wait_timeout`.
5. `pool_recycle` periodically refreshes connections to prevent long-lived
   connections from becoming stale.

Pool Configuration:
- pool_size=10:      10 persistent connections in the pool
- max_overflow=20:   Up to 20 additional connections under burst load
- pool_pre_ping=True: Validate connection liveness before checkout
- pool_recycle=3600:  Recycle connections every hour
"""

import logging
from collections.abc import Generator
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, Session

from app.core.config import get_settings

logger = logging.getLogger(__name__)

settings = get_settings()

if settings.USE_SQLITE:
    # SQLite uses StaticPool; pool_size/max_overflow/pool_recycle are not supported.
    # connect_args={"check_same_thread": False} is required for FastAPI's async threads.
    from sqlalchemy.pool import StaticPool

    engine = create_engine(
        settings.DATABASE_URL,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
        echo=settings.DEBUG,
    )
    logger.info("Using SQLite database: %s", settings.SQLITE_PATH)
else:
    engine = create_engine(
        settings.DATABASE_URL,
        pool_size=settings.DB_POOL_SIZE,
        max_overflow=settings.DB_MAX_OVERFLOW,
        pool_recycle=settings.DB_POOL_RECYCLE,
        pool_pre_ping=settings.DB_POOL_PRE_PING,
        echo=settings.DEBUG,
    )
    logger.info("Using MySQL database: %s:%s/%s", settings.DB_HOST, settings.DB_PORT, settings.DB_NAME)

SessionLocal = sessionmaker(
    autocommit=False,
    autoflush=False,
    bind=engine,
)


def get_db() -> Generator[Session, None, None]:
    """
    Dependency that provides a database session per request.
    
    The session is automatically closed after the request completes,
    ensuring connections are returned to the pool.
    """
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
