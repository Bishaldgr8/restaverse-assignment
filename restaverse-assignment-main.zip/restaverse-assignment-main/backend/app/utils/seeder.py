"""
Database seeder utility.

Generates 100 realistic employee records using the Faker library.
The seeder is idempotent — it checks if data already exists before inserting.
"""

import logging
import random
from datetime import date, timedelta
from faker import Faker

from sqlalchemy.orm import Session

from app.models.employee import Employee

logger = logging.getLogger(__name__)
fake = Faker('en_IN')
Faker.seed(42)
random.seed(42)

# Realistic department and designation data
DEPARTMENTS = [
    "Engineering",
    "Marketing",
    "Sales",
    "Human Resources",
    "Finance",
    "Product",
    "Design",
    "Operations",
    "Legal",
    "Customer Support",
]

DESIGNATIONS_BY_DEPARTMENT = {
    "Engineering": [
        "Software Engineer",
        "Senior Software Engineer",
        "Staff Engineer",
        "Principal Engineer",
        "Engineering Manager",
        "DevOps Engineer",
        "QA Engineer",
        "Frontend Developer",
        "Backend Developer",
        "Full Stack Developer",
    ],
    "Marketing": [
        "Marketing Analyst",
        "Senior Marketing Manager",
        "Content Strategist",
        "SEO Specialist",
        "Brand Manager",
        "Growth Manager",
        "Digital Marketing Lead",
    ],
    "Sales": [
        "Sales Executive",
        "Senior Sales Manager",
        "Account Executive",
        "Business Development Rep",
        "Sales Director",
        "Regional Sales Manager",
        "Enterprise Account Manager",
    ],
    "Human Resources": [
        "HR Coordinator",
        "Senior HR Manager",
        "Talent Acquisition Lead",
        "HR Business Partner",
        "Compensation Analyst",
        "People Operations Manager",
    ],
    "Finance": [
        "Financial Analyst",
        "Senior Accountant",
        "Finance Manager",
        "Controller",
        "Treasury Analyst",
        "FP&A Manager",
    ],
    "Product": [
        "Product Manager",
        "Senior Product Manager",
        "Product Owner",
        "Product Analyst",
        "Director of Product",
        "Associate Product Manager",
    ],
    "Design": [
        "UI Designer",
        "UX Designer",
        "Senior Product Designer",
        "Design Lead",
        "UX Researcher",
        "Visual Designer",
    ],
    "Operations": [
        "Operations Analyst",
        "Operations Manager",
        "Supply Chain Coordinator",
        "Process Improvement Lead",
        "Logistics Manager",
    ],
    "Legal": [
        "Legal Counsel",
        "Senior Legal Advisor",
        "Compliance Officer",
        "Contract Manager",
        "Paralegal",
    ],
    "Customer Support": [
        "Support Specialist",
        "Senior Support Engineer",
        "Customer Success Manager",
        "Technical Support Lead",
        "Support Operations Manager",
    ],
}


def generate_employees(count: int = 100) -> list[dict]:
    """Generate a list of realistic employee data dictionaries."""
    employees = []
    used_emails = set()

    for _ in range(count):
        first_name = fake.first_name()
        last_name = fake.last_name()
        name = f"{first_name} {last_name}"

        # Generate unique email
        base_email = f"{first_name.lower()}.{last_name.lower()}@company.com"
        email = base_email
        counter = 1
        while email in used_emails:
            email = f"{first_name.lower()}.{last_name.lower()}{counter}@company.com"
            counter += 1
        used_emails.add(email)

        department = random.choice(DEPARTMENTS)
        designation = random.choice(DESIGNATIONS_BY_DEPARTMENT[department])

        # Random joining date within the last 10 years
        days_ago = random.randint(30, 3650)
        date_of_joining = date.today() - timedelta(days=days_ago)

        employees.append({
            "name": name,
            "email": email,
            "department": department,
            "designation": designation,
            "date_of_joining": date_of_joining,
        })

    return employees


def seed_database(db: Session) -> None:
    """
    Seed the database with sample employee data.
    
    Idempotent: skips seeding if employees already exist.
    """
    existing_count = db.query(Employee).count()
    if existing_count > 0:
        logger.info(
            "Database already contains %d employees. Skipping seed.",
            existing_count,
        )
        return

    logger.info("Seeding database with 100 employees...")
    employees_data = generate_employees(100)

    employee_objects = [Employee(**data) for data in employees_data]
    db.bulk_save_objects(employee_objects)
    db.commit()

    logger.info("Successfully seeded %d employees.", len(employee_objects))
