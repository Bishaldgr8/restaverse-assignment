"""
Pydantic schemas for request validation and response serialization.

These schemas ensure:
- Only required fields are returned to the client (no internal fields like created_at)
- Input is validated before reaching the service layer
- Consistent response structure across all endpoints
"""

from datetime import date
from enum import Enum
from pydantic import BaseModel, Field, ConfigDict


# ─── Enums ───────────────────────────────────────────────────────────────────

class SortField(str, Enum):
    """Allowed fields for sorting employees."""
    NAME = "name"
    DEPARTMENT = "department"
    DESIGNATION = "designation"
    DATE_OF_JOINING = "date_of_joining"


class SortOrder(str, Enum):
    """Sort direction."""
    ASC = "asc"
    DESC = "desc"


# ─── Response Schemas ────────────────────────────────────────────────────────

class EmployeeResponse(BaseModel):
    """Employee data returned to the client."""

    model_config = ConfigDict(from_attributes=True)

    id: int
    name: str
    email: str
    department: str
    designation: str
    date_of_joining: date


class PaginationMeta(BaseModel):
    """Pagination metadata included in paginated responses."""

    current_page: int
    page_size: int
    total_items: int
    total_pages: int
    has_next: bool
    has_previous: bool


class PaginatedEmployeeResponse(BaseModel):
    """Paginated response wrapper for employee search results."""

    success: bool = True
    message: str = "Employees retrieved successfully"
    data: list[EmployeeResponse]
    pagination: PaginationMeta


class DepartmentListResponse(BaseModel):
    """Response containing list of all departments."""

    success: bool = True
    message: str = "Departments retrieved successfully"
    data: list[str]


class HealthResponse(BaseModel):
    """Health check response."""

    status: str
    database: str
    version: str
