"""
Employee service — business logic layer.

This layer contains all business logic and orchestrates between
the API routes and the repository. Route handlers remain thin,
only handling HTTP concerns (request parsing, status codes).

Responsibilities:
- Input sanitization and validation
- Pagination calculation (offset, total_pages, has_next/has_prev)
- Mapping ORM models to Pydantic response schemas
- Error handling with appropriate custom exceptions
"""

import logging
import math
from sqlalchemy.exc import SQLAlchemyError

from app.core.config import get_settings
from app.core.exceptions import (
    DatabaseException,
    NotFoundException,
    ValidationException,
)
from app.repositories.employee_repository import EmployeeRepository
from app.schemas.employee import (
    EmployeeResponse,
    PaginatedEmployeeResponse,
    PaginationMeta,
    SortField,
    SortOrder,
)

logger = logging.getLogger(__name__)
settings = get_settings()


class EmployeeService:
    """Business logic for employee operations."""

    def __init__(self, repository: EmployeeRepository):
        self.repository = repository

    def search_employees(
        self,
        search: str | None = None,
        department: str | None = None,
        page: int = 1,
        limit: int = 20,
        sort_by: SortField = SortField.NAME,
        sort_order: SortOrder = SortOrder.ASC,
    ) -> PaginatedEmployeeResponse:
        """
        Search employees with validation, pagination, and sorting.

        Validates inputs before querying, calculates pagination metadata,
        and returns a structured response.
        """
        # Validate pagination parameters
        page = max(1, page)
        limit = min(max(1, limit), settings.MAX_PAGE_SIZE)

        # Sanitize search input
        search_term = search.strip() if search else None
        if search_term == "":
            search_term = None

        # Sanitize department filter
        dept_filter = department.strip() if department else None
        if dept_filter == "":
            dept_filter = None

        try:
            # Get total count for pagination
            total_items = self.repository.count(
                search_term=search_term,
                department=dept_filter,
            )

            # Calculate pagination
            total_pages = math.ceil(total_items / limit) if total_items > 0 else 0
            offset = (page - 1) * limit

            # Fetch employees
            employees = self.repository.search(
                search_term=search_term,
                department=dept_filter,
                sort_by=sort_by,
                sort_order=sort_order,
                offset=offset,
                limit=limit,
            )

            # Map to response schema
            employee_data = [
                EmployeeResponse.model_validate(emp) for emp in employees
            ]

            pagination = PaginationMeta(
                current_page=page,
                page_size=limit,
                total_items=total_items,
                total_pages=total_pages,
                has_next=page < total_pages,
                has_previous=page > 1,
            )

            message = (
                f"Found {total_items} employee(s)"
                if total_items > 0
                else "No employees found matching your search"
            )

            return PaginatedEmployeeResponse(
                success=True,
                message=message,
                data=employee_data,
                pagination=pagination,
            )

        except SQLAlchemyError as e:
            logger.exception("Database error during employee search: %s", str(e))
            raise DatabaseException(
                message="Failed to search employees. Please try again later."
            )

    def get_departments(self) -> list[str]:
        """Retrieve all unique departments."""
        try:
            return self.repository.get_distinct_departments()
        except SQLAlchemyError as e:
            logger.exception("Database error fetching departments: %s", str(e))
            raise DatabaseException(
                message="Failed to retrieve departments. Please try again later."
            )

    def get_employee_by_id(self, employee_id: int) -> EmployeeResponse:
        """Retrieve a single employee by ID."""
        if employee_id < 1:
            raise ValidationException(message="Employee ID must be a positive integer.")

        try:
            employee = self.repository.get_by_id(employee_id)
        except SQLAlchemyError as e:
            logger.exception("Database error fetching employee %d: %s", employee_id, str(e))
            raise DatabaseException(
                message="Failed to retrieve employee. Please try again later."
            )

        if not employee:
            raise NotFoundException(
                message=f"Employee with ID {employee_id} not found."
            )

        return EmployeeResponse.model_validate(employee)
