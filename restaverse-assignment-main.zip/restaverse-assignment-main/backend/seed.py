"""
Standalone seed script entry point.

Usage: python seed.py

This script can be run independently to populate the database
with sample employee data. It's also called automatically
during application startup.
"""

import logging
from app.database.base import Base
from app.database.session import engine, SessionLocal
from app.utils.seeder import seed_database

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def main() -> None:
    """Create tables and seed the database."""
    logger.info("Creating database tables...")
    Base.metadata.create_all(bind=engine)

    logger.info("Running database seeder...")
    db = SessionLocal()
    try:
        seed_database(db)
        logger.info("Seeding complete!")
    except Exception as e:
        logger.error("Seeding failed: %s", str(e))
        raise
    finally:
        db.close()


if __name__ == "__main__":
    main()
