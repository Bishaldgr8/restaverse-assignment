import pymysql
import sys
from app.core.config import get_settings

settings = get_settings()

passwords = [settings.DB_PASSWORD, "", "root", "admin", "1234", "123456"]
success = False

for pwd in passwords:
    try:
        conn = pymysql.connect(
            host=settings.DB_HOST,
            port=settings.DB_PORT,
            user=settings.DB_USER,
            password=pwd,
        )
        cursor = conn.cursor()
        cursor.execute(f"CREATE DATABASE IF NOT EXISTS {settings.DB_NAME} CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;")
        print(f"Success! Connected to MySQL as root using password: '{pwd}'")
        print(f"Database '{settings.DB_NAME}' created or verified successfully.")
        conn.close()
        
        # Update .env file with the working password
        if pwd != settings.DB_PASSWORD:
            with open(".env", "r") as f:
                lines = f.readlines()
            with open(".env", "w") as f:
                for line in lines:
                    if line.startswith("DB_PASSWORD="):
                        f.write(f"DB_PASSWORD={pwd}\n")
                    else:
                        f.write(line)
            print("Updated .env file with the working password.")
            
        success = True
        break
    except Exception as e:
        continue

if not success:
    print("Could not connect to local MySQL instance. Please enter your MySQL root password in backend/.env manually.")
    sys.exit(1)
