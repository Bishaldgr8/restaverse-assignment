"""
API integration tests for employee endpoints.

Uses FastAPI's TestClient to test the full request/response cycle
with a mocked service layer.
"""

import pytest
from unittest.mock import MagicMock, patch
from datetime import date

from fastapi.testclient import TestClient

from app.main import app
from app.api.dependencies import get_employee_service
from app.services.employee_service import EmployeeService
from app.schemas.employee import (
    PaginatedEmployeeResponse,
    PaginationMeta,
    EmployeeResponse,
)
from app.core.exceptions import DatabaseException


# Create a mock service
mock_service = MagicMock(spec=EmployeeService)


def override_get_employee_service():
    return mock_service


app.dependency_overrides[get_employee_service] = override_get_employee_service
client = TestClient(app, raise_server_exceptions=False)


@pytest.fixture(autouse=True)
def reset_mock():
    """Reset mock before each test."""
    mock_service.reset_mock()


class TestSearchEndpoint:
    """Tests for GET /api/v1/employees."""

    def test_search_returns_200(self):
        """Should return 200 with paginated results."""
        mock_service.search_employees.return_value = PaginatedEmployeeResponse(
            success=True,
            message="Found 1 employee(s)",
            data=[
                EmployeeResponse(
                    id=1,
                    name="Rahul Sharma",
                    email="rahul@company.com",
                    department="Engineering",
                    designation="Software Engineer",
                    date_of_joining=date(2022, 1, 1),
                )
            ],
            pagination=PaginationMeta(
                current_page=1,
                page_size=20,
                total_items=1,
                total_pages=1,
                has_next=False,
                has_previous=False,
            ),
        )

        response = client.get("/api/v1/employees?search=rahul")

        assert response.status_code == 200
        data = response.json()
        assert data["success"] is True
        assert len(data["data"]) == 1
        assert data["data"][0]["name"] == "Rahul Sharma"

    def test_search_with_pagination_params(self):
        """Should pass pagination params to service."""
        mock_service.search_employees.return_value = PaginatedEmployeeResponse(
            success=True,
            message="Found 0 employee(s)",
            data=[],
            pagination=PaginationMeta(
                current_page=2,
                page_size=10,
                total_items=0,
                total_pages=0,
                has_next=False,
                has_previous=False,
            ),
        )

        response = client.get("/api/v1/employees?page=2&limit=10")

        assert response.status_code == 200
        mock_service.search_employees.assert_called_once()

    def test_invalid_page_returns_422(self):
        """Should return 422 for invalid page number."""
        response = client.get("/api/v1/employees?page=-1")
        assert response.status_code == 422

    def test_invalid_limit_returns_422(self):
        """Should return 422 for limit exceeding max."""
        response = client.get("/api/v1/employees?limit=0")
        assert response.status_code == 422

    def test_search_with_department_filter(self):
        """Should forward department filter to service."""
        mock_service.search_employees.return_value = PaginatedEmployeeResponse(
            success=True,
            data=[],
            pagination=PaginationMeta(
                current_page=1, page_size=20, total_items=0,
                total_pages=0, has_next=False, has_previous=False,
            ),
        )

        response = client.get("/api/v1/employees?department=Engineering")
        assert response.status_code == 200

    def test_search_with_sort_params(self):
        """Should forward sort parameters to service."""
        mock_service.search_employees.return_value = PaginatedEmployeeResponse(
            success=True,
            data=[],
            pagination=PaginationMeta(
                current_page=1, page_size=20, total_items=0,
                total_pages=0, has_next=False, has_previous=False,
            ),
        )

        response = client.get("/api/v1/employees?sort_by=department&sort_order=desc")
        assert response.status_code == 200


class TestDepartmentsEndpoint:
    """Tests for GET /api/v1/employees/departments."""

    def test_returns_department_list(self):
        """Should return list of departments."""
        mock_service.get_departments.return_value = [
            "Design", "Engineering", "Marketing"
        ]

        response = client.get("/api/v1/employees/departments")

        assert response.status_code == 200
        data = response.json()
        assert data["success"] is True
        assert len(data["data"]) == 3


class TestHealthEndpoint:
    """Tests for GET /api/v1/health."""

    def test_health_returns_200(self):
        """Should return health status."""
        response = client.get("/api/v1/health")
        assert response.status_code == 200
        data = response.json()
        assert "status" in data
        assert "database" in data
