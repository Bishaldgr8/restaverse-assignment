"""
Test fixtures and configuration.
"""

import pytest
from unittest.mock import MagicMock
from datetime import date

from app.models.employee import Employee
from app.repositories.employee_repository import EmployeeRepository
from app.services.employee_service import EmployeeService


@pytest.fixture
def mock_db():
    """Provide a mock database session."""
    return MagicMock()


@pytest.fixture
def mock_repository():
    """Provide a mock EmployeeRepository."""
    return MagicMock(spec=EmployeeRepository)


@pytest.fixture
def employee_service(mock_repository):
    """Provide an EmployeeService with a mock repository."""
    return EmployeeService(repository=mock_repository)


@pytest.fixture
def sample_employees():
    """Provide sample Employee model instances for testing."""
    return [
        Employee(
            id=1,
            name="Rahul Sharma",
            email="rahul.sharma@company.com",
            department="Engineering",
            designation="Senior Software Engineer",
            date_of_joining=date(2022, 3, 15),
        ),
        Employee(
            id=2,
            name="Priya Patel",
            email="priya.patel@company.com",
            department="Marketing",
            designation="Marketing Manager",
            date_of_joining=date(2021, 7, 1),
        ),
        Employee(
            id=3,
            name="Amit Kumar",
            email="amit.kumar@company.com",
            department="Engineering",
            designation="DevOps Engineer",
            date_of_joining=date(2023, 1, 10),
        ),
    ]
