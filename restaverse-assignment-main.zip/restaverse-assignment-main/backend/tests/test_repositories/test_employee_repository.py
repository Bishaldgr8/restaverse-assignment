"""
Unit tests for EmployeeRepository.

Tests the data access layer methods using a mock database session.
"""

import pytest
from unittest.mock import MagicMock, patch, PropertyMock

from app.repositories.employee_repository import EmployeeRepository
from app.schemas.employee import SortField, SortOrder


class TestEmployeeRepository:
    """Tests for EmployeeRepository methods."""

    def test_repository_initializes_with_session(self, mock_db):
        """Repository should accept and store a database session."""
        repo = EmployeeRepository(mock_db)
        assert repo.db is mock_db

    def test_search_calls_query_with_offset_limit(self, mock_db):
        """Search should apply offset and limit to the query."""
        repo = EmployeeRepository(mock_db)
        mock_query = MagicMock()
        mock_db.query.return_value = mock_query
        mock_query.filter.return_value = mock_query
        mock_query.order_by.return_value = mock_query
        mock_query.offset.return_value = mock_query
        mock_query.limit.return_value = mock_query
        mock_query.all.return_value = []

        repo.search(offset=20, limit=10)

        mock_query.offset.assert_called_once_with(20)
        mock_query.limit.assert_called_once_with(10)

    def test_search_with_search_term_applies_filter(self, mock_db):
        """Search with a term should apply ILIKE filter."""
        repo = EmployeeRepository(mock_db)
        mock_query = MagicMock()
        mock_db.query.return_value = mock_query
        mock_query.filter.return_value = mock_query
        mock_query.order_by.return_value = mock_query
        mock_query.offset.return_value = mock_query
        mock_query.limit.return_value = mock_query
        mock_query.all.return_value = []

        repo.search(search_term="rahul")

        # filter should have been called (for the search term)
        mock_query.filter.assert_called()

    def test_get_distinct_departments(self, mock_db):
        """Should return unique department names."""
        repo = EmployeeRepository(mock_db)
        mock_query = MagicMock()
        mock_db.query.return_value = mock_query
        mock_query.distinct.return_value = mock_query
        mock_query.order_by.return_value = mock_query
        mock_query.all.return_value = [("Design",), ("Engineering",), ("Marketing",)]

        result = repo.get_distinct_departments()

        assert result == ["Design", "Engineering", "Marketing"]

    def test_get_by_id(self, mock_db):
        """Should query by primary key."""
        repo = EmployeeRepository(mock_db)
        mock_query = MagicMock()
        mock_db.query.return_value = mock_query
        mock_query.filter.return_value = mock_query
        mock_query.first.return_value = None

        result = repo.get_by_id(999)

        assert result is None
        mock_query.filter.assert_called()

    def test_count_returns_scalar(self, mock_db):
        """Count should return the scalar result."""
        repo = EmployeeRepository(mock_db)
        mock_query = MagicMock()
        mock_db.query.return_value = mock_query
        mock_query.filter.return_value = mock_query
        mock_query.scalar.return_value = 42

        result = repo.count()

        assert result == 42
