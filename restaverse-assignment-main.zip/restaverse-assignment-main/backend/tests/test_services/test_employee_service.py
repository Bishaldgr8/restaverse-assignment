"""
Unit tests for EmployeeService.

Tests the business logic layer in isolation by mocking the repository.
"""

import pytest
from unittest.mock import MagicMock
from sqlalchemy.exc import OperationalError

from app.services.employee_service import EmployeeService
from app.schemas.employee import SortField, SortOrder
from app.core.exceptions import DatabaseException, NotFoundException, ValidationException


class TestSearchEmployees:
    """Tests for EmployeeService.search_employees."""

    def test_search_returns_paginated_response(self, employee_service, mock_repository, sample_employees):
        """Should return a properly structured paginated response."""
        mock_repository.count.return_value = 3
        mock_repository.search.return_value = sample_employees

        result = employee_service.search_employees(search="eng", page=1, limit=20)

        assert result.success is True
        assert len(result.data) == 3
        assert result.pagination.current_page == 1
        assert result.pagination.total_items == 3
        assert result.pagination.total_pages == 1
        assert result.pagination.has_next is False
        assert result.pagination.has_previous is False

    def test_search_with_empty_string_treats_as_none(self, employee_service, mock_repository):
        """Empty search string should be treated as no search filter."""
        mock_repository.count.return_value = 0
        mock_repository.search.return_value = []

        employee_service.search_employees(search="   ", page=1, limit=20)

        mock_repository.count.assert_called_once_with(
            search_term=None, department=None
        )

    def test_search_returns_empty_state(self, employee_service, mock_repository):
        """Should return success with empty data when no results found."""
        mock_repository.count.return_value = 0
        mock_repository.search.return_value = []

        result = employee_service.search_employees(search="nonexistent")

        assert result.success is True
        assert len(result.data) == 0
        assert result.pagination.total_items == 0
        assert result.pagination.total_pages == 0

    def test_pagination_calculation(self, employee_service, mock_repository, sample_employees):
        """Should correctly calculate pagination metadata."""
        mock_repository.count.return_value = 50
        mock_repository.search.return_value = sample_employees[:2]

        result = employee_service.search_employees(page=2, limit=10)

        assert result.pagination.current_page == 2
        assert result.pagination.total_pages == 5
        assert result.pagination.has_next is True
        assert result.pagination.has_previous is True

    def test_page_clamped_to_minimum_1(self, employee_service, mock_repository):
        """Page number below 1 should be clamped to 1."""
        mock_repository.count.return_value = 0
        mock_repository.search.return_value = []

        employee_service.search_employees(page=-5, limit=20)

        # Verify offset is 0 (page 1)
        mock_repository.search.assert_called_once()
        call_kwargs = mock_repository.search.call_args[1]
        assert call_kwargs["offset"] == 0

    def test_limit_clamped_to_max(self, employee_service, mock_repository):
        """Limit exceeding MAX_PAGE_SIZE should be clamped."""
        mock_repository.count.return_value = 0
        mock_repository.search.return_value = []

        employee_service.search_employees(page=1, limit=9999)

        call_kwargs = mock_repository.search.call_args[1]
        assert call_kwargs["limit"] <= 100

    def test_database_error_raises_exception(self, employee_service, mock_repository):
        """Database errors should be wrapped in DatabaseException."""
        mock_repository.count.side_effect = OperationalError(
            "SELECT", {}, Exception("Connection refused")
        )

        with pytest.raises(DatabaseException):
            employee_service.search_employees(search="test")

    def test_sort_parameters_passed_to_repository(self, employee_service, mock_repository):
        """Sort parameters should be forwarded to the repository."""
        mock_repository.count.return_value = 0
        mock_repository.search.return_value = []

        employee_service.search_employees(
            sort_by=SortField.DEPARTMENT,
            sort_order=SortOrder.DESC,
        )

        call_kwargs = mock_repository.search.call_args[1]
        assert call_kwargs["sort_by"] == SortField.DEPARTMENT
        assert call_kwargs["sort_order"] == SortOrder.DESC


class TestGetEmployeeById:
    """Tests for EmployeeService.get_employee_by_id."""

    def test_returns_employee_when_found(self, employee_service, mock_repository, sample_employees):
        """Should return employee data when ID exists."""
        mock_repository.get_by_id.return_value = sample_employees[0]

        result = employee_service.get_employee_by_id(1)

        assert result.id == 1
        assert result.name == "Rahul Sharma"

    def test_raises_not_found_when_missing(self, employee_service, mock_repository):
        """Should raise NotFoundException when employee doesn't exist."""
        mock_repository.get_by_id.return_value = None

        with pytest.raises(NotFoundException):
            employee_service.get_employee_by_id(999)

    def test_raises_validation_for_invalid_id(self, employee_service):
        """Should raise ValidationException for non-positive IDs."""
        with pytest.raises(ValidationException):
            employee_service.get_employee_by_id(-1)


class TestGetDepartments:
    """Tests for EmployeeService.get_departments."""

    def test_returns_department_list(self, employee_service, mock_repository):
        """Should return list of department strings."""
        mock_repository.get_distinct_departments.return_value = [
            "Design", "Engineering", "Marketing"
        ]

        result = employee_service.get_departments()

        assert len(result) == 3
        assert "Engineering" in result
