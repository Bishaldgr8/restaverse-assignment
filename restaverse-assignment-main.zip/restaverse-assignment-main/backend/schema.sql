-- ============================================================================
-- Employee Directory Database Schema
-- ============================================================================
-- This schema is auto-created by SQLAlchemy on app startup.
-- This file serves as documentation and manual setup reference.
-- ============================================================================

CREATE DATABASE IF NOT EXISTS employee_directory
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE employee_directory;

-- ============================================================================
-- Employees Table
-- ============================================================================
-- 
-- Indexes:
--   idx_employee_name:      B-tree index on name for fast name searches.
--                           Prefix searches (LIKE 'rahul%') use index range scan.
--   idx_employee_department: B-tree index on department for fast department filtering.
--   idx_employee_name_dept: Composite index covering combined name+department searches.
--                           Eliminates the need for a table lookup when both fields
--                           are used in WHERE clause (covering index optimization).
--
-- Engine: InnoDB for ACID compliance and row-level locking under concurrent access.
-- Charset: utf8mb4 for full Unicode support (including emojis in names).
-- ============================================================================

CREATE TABLE IF NOT EXISTS employees (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    name            VARCHAR(100)    NOT NULL,
    email           VARCHAR(150)    NOT NULL UNIQUE,
    department      VARCHAR(50)     NOT NULL,
    designation     VARCHAR(100)    NOT NULL,
    date_of_joining DATE            NOT NULL,
    created_at      TIMESTAMP       DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP       DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    -- Performance indexes
    INDEX idx_employee_name (name),
    INDEX idx_employee_department (department),
    INDEX idx_employee_name_dept (name, department)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
