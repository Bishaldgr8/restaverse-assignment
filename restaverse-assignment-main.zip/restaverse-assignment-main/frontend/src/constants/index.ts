/**
 * Application constants.
 */

export const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000/api/v1';

export const DEFAULTS = {
  PAGE: 1,
  LIMIT: 12,
  SORT_BY: 'name' as const,
  SORT_ORDER: 'asc' as const,
};

export const RECENT_SEARCHES_KEY = 'employee_directory_recent_searches';
export const MAX_RECENT_SEARCHES = 5;
