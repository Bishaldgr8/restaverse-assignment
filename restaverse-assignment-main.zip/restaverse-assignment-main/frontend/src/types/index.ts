/**
 * Central type definitions for the Employee Directory application.
 *
 * All TypeScript interfaces are defined here to ensure consistency
 * across the application and avoid duplicated type declarations.
 */

// ─── Employee Types ─────────────────────────────────────────────────────────

export interface Employee {
  id: number;
  name: string;
  email: string;
  department: string;
  designation: string;
  date_of_joining: string;
}

// ─── API Response Types ─────────────────────────────────────────────────────

export interface PaginationMeta {
  current_page: number;
  page_size: number;
  total_items: number;
  total_pages: number;
  has_next: boolean;
  has_previous: boolean;
}

export interface PaginatedResponse<T> {
  success: boolean;
  message: string;
  data: T[];
  pagination: PaginationMeta;
}

export interface DepartmentResponse {
  success: boolean;
  message: string;
  data: string[];
}

export type EmployeePaginatedResponse = PaginatedResponse<Employee>;

// ─── Search & Filter Types ──────────────────────────────────────────────────

export type SortField = "name" | "department" | "designation" | "date_of_joining";
export type SortOrder = "asc" | "desc";

export interface SearchParams {
  search?: string;
  department?: string;
  page: number;
  limit: number;
  sort_by: SortField;
  sort_order: SortOrder;
}

// ─── UI State Types ─────────────────────────────────────────────────────────

export interface SearchFilters {
  search: string;
  department: string;
  sortBy: SortField;
  sortOrder: SortOrder;
  page: number;
}

export interface RecentSearch {
  term: string;
  timestamp: number;
}

// ─── API Error Type ─────────────────────────────────────────────────────────

export interface ApiError {
  success: false;
  message: string;
  data: null;
}
