import { useState, useEffect } from 'react';

/**
 * Custom hook to debounce a value.
 *
 * Useful for delaying expensive operations like API calls until a user
 * stops typing. Typing "R" -> "Ra" -> "Rah" -> "Rahul" will result in
 * only a single update to the debounced value after the delay.
 *
 * @param value The value to debounce.
 * @param delay The delay in milliseconds (default 500ms).
 */
export function useDebounce<T>(value: T, delay = 500): T {
  const [debouncedValue, setDebouncedValue] = useState<T>(value);

  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedValue(value);
    }, delay);

    return () => {
      clearTimeout(handler);
    };
  }, [value, delay]);

  return debouncedValue;
}
