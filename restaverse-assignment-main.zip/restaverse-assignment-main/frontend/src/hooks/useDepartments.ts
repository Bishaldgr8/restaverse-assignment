import { useQuery } from '@tanstack/react-query';
import { employeeService } from '../services/employeeService';

export function useDepartments() {
  const query = useQuery({
    queryKey: ['departments'],
    queryFn: () => employeeService.getDepartments(),
    staleTime: 5 * 60 * 1000, // 5 minutes stale time
    gcTime: 10 * 60 * 1000, // 10 minutes cache cleanup
    retry: 1,
  });

  return {
    departments: query.data?.data ?? [],
    isLoading: query.isLoading,
    isError: query.isError,
    error: query.error as { message: string } | null,
  };
}
