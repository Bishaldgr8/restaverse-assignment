import { useQuery, keepPreviousData } from '@tanstack/react-query';
import { employeeService } from '../services/employeeService';
import { SearchParams } from '../types';

/**
 * Custom React Query hook for employee search.
 *
 * Utilizes caching, query key dependencies for automatic refetching,
 * pagination placeholder mapping, and exponential backoff retry.
 */
export function useEmployees(params: SearchParams) {
  const query = useQuery({
    queryKey: ['employees', params],
    queryFn: () => employeeService.searchEmployees(params),
    placeholderData: keepPreviousData, // Keep older data visible during pagination transitions
    staleTime: 30000, // 30 seconds stale time
    gcTime: 5 * 60 * 1000, // 5 minutes garbage collection time (cacheTime in React Query v4)
    retry: 2, // Retry twice before displaying error state
    retryDelay: (attemptIndex) => Math.min(1000 * 2 ** attemptIndex, 3000), // Exponential backoff
  });

  return {
    employees: query.data?.data ?? [],
    pagination: query.data?.pagination,
    isLoading: query.isLoading,
    isFetching: query.isFetching,
    isError: query.isError,
    error: query.error as { message: string } | null,
    refetch: query.refetch,
  };
}
