import { describe, it, expect, vi } from 'vitest';
import { renderHook, act } from '@testing-library/react';
import { useDebounce } from '../useDebounce';

describe('useDebounce Hook', () => {
  it('returns the initial value immediately', () => {
    const { result } = renderHook(() => useDebounce('initial', 500));
    expect(result.current).toBe('initial');
  });

  it('updates the debounced value only after the specified delay', () => {
    vi.useFakeTimers();
    
    let value = 'initial';
    const { result, rerender } = renderHook(() => useDebounce(value, 500));
    
    // Change value
    value = 'updated';
    rerender();
    
    // Should still be initial immediately
    expect(result.current).toBe('initial');
    
    // Advance timers by 250ms
    act(() => {
      vi.advanceTimersByTime(250);
    });
    expect(result.current).toBe('initial');
    
    // Advance timers by another 250ms (total 500ms)
    act(() => {
      vi.advanceTimersByTime(250);
    });
    expect(result.current).toBe('updated');
    
    vi.useRealTimers();
  });
});
