import { useState, useEffect, useCallback } from 'react';
import { RECENT_SEARCHES_KEY, MAX_RECENT_SEARCHES } from '../constants';
import { RecentSearch } from '../types';

export function useRecentSearches() {
  const [searches, setSearches] = useState<RecentSearch[]>([]);

  // Load from localStorage on mount
  useEffect(() => {
    try {
      const stored = localStorage.getItem(RECENT_SEARCHES_KEY);
      if (stored) {
        setSearches(JSON.parse(stored));
      }
    } catch (error) {
      console.error('Failed to parse recent searches from localStorage:', error);
    }
  }, []);

  const addSearch = useCallback((term: string) => {
    const trimmed = term.trim();
    if (!trimmed) return;

    setSearches((prev) => {
      // Filter out existing occurrence of the same term to push to top
      const filtered = prev.filter((item) => item.term.toLowerCase() !== trimmed.toLowerCase());
      
      const updated = [
        { term: trimmed, timestamp: Date.now() },
        ...filtered,
      ].slice(0, MAX_RECENT_SEARCHES);

      try {
        localStorage.setItem(RECENT_SEARCHES_KEY, JSON.stringify(updated));
      } catch (error) {
        console.error('Failed to save recent searches to localStorage:', error);
      }

      return updated;
    });
  }, []);

  const clearSearches = useCallback(() => {
    setSearches([]);
    try {
      localStorage.removeItem(RECENT_SEARCHES_KEY);
    } catch (error) {
      console.error('Failed to clear recent searches from localStorage:', error);
    }
  }, []);

  const removeSearch = useCallback((termToRemove: string) => {
    setSearches((prev) => {
      const updated = prev.filter((item) => item.term !== termToRemove);
      try {
        localStorage.setItem(RECENT_SEARCHES_KEY, JSON.stringify(updated));
      } catch (error) {
        console.error('Failed to update recent searches in localStorage:', error);
      }
      return updated;
    });
  }, []);

  return {
    searches,
    addSearch,
    clearSearches,
    removeSearch,
  };
}
