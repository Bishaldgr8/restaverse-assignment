import axiosClient from '../api/axiosClient';
import { Employee, EmployeePaginatedResponse, SearchParams, DepartmentResponse } from '../types';

export const employeeService = {
  /**
   * Search employees with filters, sorting, and pagination.
   */
  async searchEmployees(params: SearchParams): Promise<EmployeePaginatedResponse> {
    const queryParams = new URLSearchParams();
    
    if (params.search?.trim()) {
      queryParams.append('search', params.search.trim());
    }
    
    if (params.department && params.department !== 'All Departments') {
      queryParams.append('department', params.department);
    }
    
    queryParams.append('page', String(params.page));
    queryParams.append('limit', String(params.limit));
    queryParams.append('sort_by', params.sort_by);
    queryParams.append('sort_order', params.sort_order);

    const response = await axiosClient.get<EmployeePaginatedResponse>(`/employees?${queryParams.toString()}`);
    return response.data;
  },

  /**
   * Retrieve all distinct department names.
   */
  async getDepartments(): Promise<DepartmentResponse> {
    const response = await axiosClient.get<DepartmentResponse>('/employees/departments');
    return response.data;
  },

  /**
   * Get a single employee by their ID.
   */
  async getEmployeeById(id: number): Promise<Employee> {
    const response = await axiosClient.get<Employee>(`/employees/${id}`);
    return response.data;
  }
};
