import { describe, it, expect } from 'vitest';
import { render, screen } from '@testing-library/react';
import { EmployeeCard } from '../EmployeeCard';
import { Employee } from '../../types';

const mockEmployee: Employee = {
  id: 1,
  name: 'Rahul Sharma',
  email: 'rahul.sharma@company.com',
  department: 'Engineering',
  designation: 'Senior Software Engineer',
  date_of_joining: '2023-01-15',
};

describe('EmployeeCard Component', () => {
  it('renders employee information correctly', () => {
    render(<EmployeeCard employee={mockEmployee} />);
    
    // Check name
    expect(screen.getByText('Rahul Sharma')).toBeInTheDocument();
    
    // Check designation (casing is preserved in node content; styled with CSS uppercase)
    expect(screen.getByText('Senior Software Engineer')).toBeInTheDocument();
    
    // Check email
    expect(screen.getByText('rahul.sharma@company.com')).toBeInTheDocument();
    
    // Check department badge
    expect(screen.getByText('Engineering')).toBeInTheDocument();
    
    // Check formatted date
    expect(screen.getByText('Jan 15, 2023')).toBeInTheDocument();
  });

  it('renders avatar initials derived from name', () => {
    render(<EmployeeCard employee={mockEmployee} />);
    expect(screen.getByText('RS')).toBeInTheDocument();
  });
});
