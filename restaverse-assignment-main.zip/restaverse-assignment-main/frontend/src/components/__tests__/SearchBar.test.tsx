import { describe, it, expect, vi } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import { SearchBar } from '../SearchBar';

describe('SearchBar Component', () => {
  it('renders input with default placeholder', () => {
    render(<SearchBar value="" onChange={() => {}} />);
    expect(
      screen.getByPlaceholderText('Search employees by name or department...')
    ).toBeInTheDocument();
  });

  it('updates input value on change', () => {
    const handleChange = vi.fn();
    render(<SearchBar value="" onChange={handleChange} />);
    
    const input = screen.getByPlaceholderText('Search employees by name or department...') as HTMLInputElement;
    fireEvent.change(input, { target: { value: 'Rahul' } });
    
    expect(handleChange).toHaveBeenCalledWith('Rahul');
  });

  it('shows clear button and clears input on click', () => {
    const handleChange = vi.fn();
    render(<SearchBar value="Rahul" onChange={handleChange} />);
    
    const clearBtn = screen.getByLabelText('Clear search input');
    expect(clearBtn).toBeInTheDocument();
    
    fireEvent.click(clearBtn);
    expect(handleChange).toHaveBeenCalledWith('');
  });

  it('triggers onSearchSubmit on hitting Enter key', () => {
    const handleSearchSubmit = vi.fn();
    render(<SearchBar value="Rahul" onChange={() => {}} onSearchSubmit={handleSearchSubmit} />);
    
    const input = screen.getByPlaceholderText('Search employees by name or department...');
    fireEvent.keyDown(input, { key: 'Enter', code: 'Enter' });
    
    expect(handleSearchSubmit).toHaveBeenCalledWith('Rahul');
  });
});
