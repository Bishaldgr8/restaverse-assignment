import React, { useState, useRef } from 'react';
import { RecentSearches } from './RecentSearches';
import { useRecentSearches } from '../hooks/useRecentSearches';

interface SearchBarProps {
  value: string;
  onChange: (value: string) => void;
  onSearchSubmit?: (value: string) => void;
  placeholder?: string;
}

export const SearchBar: React.FC<SearchBarProps> = ({
  value,
  onChange,
  onSearchSubmit,
  placeholder = 'Search employees by name or department...',
}) => {
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const { searches, addSearch, removeSearch, clearSearches } = useRecentSearches();
  const containerRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      const term = value.trim();
      if (term) {
        addSearch(term);
        if (onSearchSubmit) {
          onSearchSubmit(term);
        }
      }
      setDropdownOpen(false);
      inputRef.current?.blur();
    }
  };

  const handleSelectRecent = (term: string) => {
    onChange(term);
    if (onSearchSubmit) {
      onSearchSubmit(term);
    }
    setDropdownOpen(false);
  };

  const handleClearInput = () => {
    onChange('');
    inputRef.current?.focus();
  };

  return (
    <div ref={containerRef} className="relative flex-1 w-full">
      <div className="relative group">
        {/* Search Icon */}
        <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none text-slate-400 group-focus-within:text-indigo-600 transition-colors">
          <svg
            className="w-5 h-5"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
            />
          </svg>
        </div>

        {/* Input Field */}
        <input
          ref={inputRef}
          type="text"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          onKeyDown={handleKeyDown}
          onFocus={() => setDropdownOpen(true)}
          placeholder={placeholder}
          className="block w-full pl-12 pr-12 py-3.5 border border-slate-200 rounded-2xl bg-white text-slate-800 placeholder-slate-400 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 hover:border-slate-300 transition-all shadow-sm"
        />

        {/* Clear Button */}
        {value && (
          <button
            onClick={handleClearInput}
            className="absolute inset-y-0 right-0 pr-4 flex items-center text-slate-400 hover:text-slate-600 transition-colors"
            aria-label="Clear search input"
          >
            <svg
              className="w-5 h-5"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
                d="M6 18L18 6M6 6l12 12"
              />
            </svg>
          </button>
        )}
      </div>

      {/* Recent Searches Dropdown */}
      <RecentSearches
        searches={searches}
        onSelect={handleSelectRecent}
        onRemove={removeSearch}
        onClear={clearSearches}
        isOpen={dropdownOpen && searches.length > 0}
        onClose={() => setDropdownOpen(false)}
      />
    </div>
  );
};
