import React from 'react';
import { PaginationMeta } from '../types';

interface PaginationProps {
  meta?: PaginationMeta;
  onPageChange: (page: number) => void;
}

export const Pagination: React.FC<PaginationProps> = ({ meta, onPageChange }) => {
  if (!meta || meta.total_pages <= 1) return null;

  const { current_page, page_size, total_items, total_pages, has_next, has_previous } = meta;

  // Calculate scope values
  const startItem = (current_page - 1) * page_size + 1;
  const endItem = Math.min(current_page * page_size, total_items);

  // Generate page numbers to display
  const getPages = () => {
    const pages: (number | string)[] = [];
    const delta = 1; // Number of pages to show before and after current page

    for (let i = 1; i <= total_pages; i++) {
      if (
        i === 1 ||
        i === total_pages ||
        (i >= current_page - delta && i <= current_page + delta)
      ) {
        pages.push(i);
      } else if (
        pages[pages.length - 1] !== '...' &&
        (i < current_page - delta || i > current_page + delta)
      ) {
        pages.push('...');
      }
    }
    return pages;
  };

  const pages = getPages();

  return (
    <div className="flex flex-col sm:flex-row justify-between items-center px-4 py-4 bg-white border border-slate-100 rounded-2xl shadow-sm gap-4 mt-8">
      {/* Scope info */}
      <span className="text-xs font-semibold text-slate-500">
        Showing <span className="text-slate-800">{startItem}</span> to{' '}
        <span className="text-slate-800">{endItem}</span> of{' '}
        <span className="text-slate-800">{total_items}</span> employees
      </span>

      {/* Page Navigation */}
      <div className="flex items-center space-x-1">
        {/* Previous Button */}
        <button
          onClick={() => onPageChange(current_page - 1)}
          disabled={!has_previous}
          className="p-2 border border-slate-200 rounded-xl bg-white hover:bg-slate-50 text-slate-600 disabled:opacity-40 disabled:hover:bg-white transition-all duration-200 active:scale-95 disabled:active:scale-100"
          aria-label="Previous page"
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 19l-7-7 7-7" />
          </svg>
        </button>

        {/* Page numbers */}
        {pages.map((page, index) =>
          typeof page === 'number' ? (
            <button
              key={index}
              onClick={() => onPageChange(page)}
              className={`w-10 h-10 text-xs font-bold rounded-xl transition-all duration-200 active:scale-95 ${
                current_page === page
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-100 border border-indigo-600'
                  : 'border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 hover:border-slate-300'
              }`}
            >
              {page}
            </button>
          ) : (
            <span
              key={index}
              className="w-8 text-center text-slate-400 text-sm font-semibold select-none"
            >
              {page}
            </span>
          )
        )}

        {/* Next Button */}
        <button
          onClick={() => onPageChange(current_page + 1)}
          disabled={!has_next}
          className="p-2 border border-slate-200 rounded-xl bg-white hover:bg-slate-50 text-slate-600 disabled:opacity-40 disabled:hover:bg-white transition-all duration-200 active:scale-95 disabled:active:scale-100"
          aria-label="Next page"
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7" />
          </svg>
        </button>
      </div>
    </div>
  );
};
