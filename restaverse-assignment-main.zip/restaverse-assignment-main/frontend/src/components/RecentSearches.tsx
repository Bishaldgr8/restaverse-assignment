import React from 'react';
import { RecentSearch } from '../types';

interface RecentSearchesProps {
  searches: RecentSearch[];
  onSelect: (term: string) => void;
  onClear: () => void;
  onRemove: (term: string) => void;
  isOpen: boolean;
  onClose: () => void;
}

export const RecentSearches: React.FC<RecentSearchesProps> = ({
  searches,
  onSelect,
  onClear,
  onRemove,
  isOpen,
  onClose,
}) => {
  if (!isOpen || searches.length === 0) return null;

  return (
    <>
      {/* Invisible backdrop to close the dropdown */}
      <div className="fixed inset-0 z-10" onClick={onClose} />
      
      <div className="absolute top-full left-0 right-0 mt-2 bg-white border border-slate-100 rounded-xl shadow-xl z-20 overflow-hidden divide-y divide-slate-50 animate-in fade-in slide-in-from-top-2 duration-150">
        <div className="flex justify-between items-center px-4 py-3 bg-slate-50">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Recent Searches</span>
          <button
            onClick={(e) => {
              e.stopPropagation();
              onClear();
            }}
            className="text-xs font-semibold text-red-500 hover:text-red-700 transition-colors"
          >
            Clear All
          </button>
        </div>
        <div className="flex flex-col max-h-60 overflow-y-auto">
          {searches.map((item) => (
            <div
              key={item.term}
              className="flex justify-between items-center px-4 py-3 hover:bg-slate-50 cursor-pointer transition-colors group"
              onClick={() => onSelect(item.term)}
            >
              <div className="flex items-center space-x-3">
                <svg
                  className="w-4 h-4 text-slate-400"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
                  />
                </svg>
                <span className="text-sm text-slate-700 group-hover:text-indigo-600 transition-colors font-medium">
                  {item.term}
                </span>
              </div>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onRemove(item.term);
                }}
                className="text-slate-300 hover:text-red-500 rounded p-1 hover:bg-slate-100 transition-all opacity-0 group-hover:opacity-100 focus:opacity-100"
                aria-label={`Remove search term ${item.term}`}
              >
                <svg
                  className="w-3.5 h-3.5"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    d="M6 18L18 6M6 6l12 12"
                  />
                </svg>
              </button>
            </div>
          ))}
        </div>
      </div>
    </>
  );
};
