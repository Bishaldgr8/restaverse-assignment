import React from 'react';
import { Employee } from '../types';
import { EmployeeCard } from './EmployeeCard';

interface EmployeeListProps {
  employees: Employee[];
  searchTerm?: string;
}

export const EmployeeList: React.FC<EmployeeListProps> = ({ employees, searchTerm }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {employees.map((employee) => (
        <EmployeeCard
          key={employee.id}
          employee={employee}
          searchTerm={searchTerm}
        />
      ))}
    </div>
  );
};
