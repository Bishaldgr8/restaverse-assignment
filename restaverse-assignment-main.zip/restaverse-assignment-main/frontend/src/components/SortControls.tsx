import React from 'react';
import { SortField, SortOrder } from '../types';

interface SortControlsProps {
  sortBy: SortField;
  sortOrder: SortOrder;
  onSortByChange: (field: SortField) => void;
  onSortOrderToggle: () => void;
}

const SORT_OPTIONS: { value: SortField; label: string }[] = [
  { value: 'name', label: 'Sort by Name' },
  { value: 'department', label: 'Sort by Department' },
  { value: 'designation', label: 'Sort by Designation' },
  { value: 'date_of_joining', label: 'Sort by Joining Date' },
];

export const SortControls: React.FC<SortControlsProps> = ({
  sortBy,
  sortOrder,
  onSortByChange,
  onSortOrderToggle,
}) => {
  return (
    <div className="flex items-center space-x-2 w-full sm:w-auto">
      {/* Field Selector */}
      <div className="relative flex-1 sm:flex-initial">
        <select
          value={sortBy}
          onChange={(e) => onSortByChange(e.target.value as SortField)}
          className="block w-full px-4 py-3.5 pr-10 border border-slate-200 rounded-2xl bg-white text-slate-700 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 hover:border-slate-300 transition-all cursor-pointer shadow-sm appearance-none"
        >
          {SORT_OPTIONS.map((opt) => (
            <option key={opt.value} value={opt.value}>
              {opt.label}
            </option>
          ))}
        </select>
        <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-4 text-slate-400">
          <svg
            className="w-4 h-4"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              d="M19 9l-7 7-7-7"
            />
          </svg>
        </div>
      </div>

      {/* Direction Toggle Button */}
      <button
        onClick={onSortOrderToggle}
        className="px-4 py-3.5 border border-slate-200 rounded-2xl bg-white text-slate-700 hover:bg-slate-50 hover:border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all shadow-sm active:scale-95 flex items-center justify-center"
        aria-label={`Sort in ${sortOrder === 'asc' ? 'descending' : 'ascending'} order`}
      >
        <svg
          className={`w-5 h-5 text-slate-500 transition-transform duration-200 ${
            sortOrder === 'desc' ? 'rotate-180' : ''
          }`}
          fill="none"
          stroke="currentColor"
          viewBox="0 0 24 24"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth="2"
            d="M3 4h13M3 8h9m-9 4h6m4 0l4-4m0 0l4 4m-4-4v12"
          />
        </svg>
      </button>
    </div>
  );
};
