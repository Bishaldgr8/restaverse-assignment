import React from 'react';

export const Header: React.FC = () => {
  return (
    <header className="sticky top-0 z-40 w-full bg-white/80 backdrop-blur-md border-b border-slate-100 px-6 py-4">
      <div className="max-w-7xl mx-auto flex justify-between items-center">
        <div className="flex items-center space-x-3">
          {/* Logo Icon */}
          <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white font-bold text-lg shadow-md shadow-indigo-200">
            R
          </div>
          <div>
            <h1 className="text-lg font-bold text-slate-800 tracking-tight leading-none">Retaverse</h1>
            <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-widest">Directory Hub</span>
          </div>
        </div>

        {/* Info/Badges */}
        <div className="flex items-center space-x-4">
          <div className="hidden sm:flex items-center space-x-2 bg-slate-50 border border-slate-100 rounded-lg px-3 py-1.5 text-xs text-slate-500 font-medium">
            <span className="w-2 h-2 rounded-full bg-green-500 animate-ping"></span>
            <span className="w-2 h-2 rounded-full bg-green-500 absolute"></span>
            <span>API Server Online</span>
          </div>
          
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 rounded-full bg-indigo-50 border border-indigo-100 flex items-center justify-center text-indigo-600 font-bold text-xs">
              AD
            </div>
            <span className="text-xs font-semibold text-slate-700 hidden md:inline-block">Admin Dashboard</span>
          </div>
        </div>
      </div>
    </header>
  );
};
