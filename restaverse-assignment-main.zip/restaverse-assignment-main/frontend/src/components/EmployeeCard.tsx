import React from 'react';
import { Employee } from '../types';
import { SearchHighlight } from './SearchHighlight';

interface EmployeeCardProps {
  employee: Employee;
  searchTerm?: string;
}

// Map departments to distinct premium colors
const DEPT_COLORS: Record<string, { bg: string; text: string; dot: string }> = {
  Engineering: { bg: 'bg-blue-50/70', text: 'text-blue-700', dot: 'bg-blue-500' },
  Marketing: { bg: 'bg-pink-50/70', text: 'text-pink-700', dot: 'bg-pink-500' },
  Sales: { bg: 'bg-amber-50/70', text: 'text-amber-700', dot: 'bg-amber-500' },
  'Human Resources': { bg: 'bg-emerald-50/70', text: 'text-emerald-700', dot: 'bg-emerald-500' },
  Finance: { bg: 'bg-violet-50/70', text: 'text-violet-700', dot: 'bg-violet-500' },
  Product: { bg: 'bg-indigo-50/70', text: 'text-indigo-700', dot: 'bg-indigo-500' },
  Design: { bg: 'bg-rose-50/70', text: 'text-rose-700', dot: 'bg-rose-500' },
  Operations: { bg: 'bg-cyan-50/70', text: 'text-cyan-700', dot: 'bg-cyan-500' },
  Legal: { bg: 'bg-slate-100/70', text: 'text-slate-700', dot: 'bg-slate-500' },
  'Customer Support': { bg: 'bg-teal-50/70', text: 'text-teal-700', dot: 'bg-teal-500' },
};

export const EmployeeCard: React.FC<EmployeeCardProps> = ({ employee, searchTerm }) => {
  // Get initials for Avatar
  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map((part) => part[0])
      .slice(0, 2)
      .join('')
      .toUpperCase();
  };

  // Format joining date
  const formatDate = (dateStr: string) => {
    try {
      return new Date(dateStr).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
      });
    } catch {
      return dateStr;
    }
  };

  const colors = DEPT_COLORS[employee.department] || {
    bg: 'bg-slate-50/70',
    text: 'text-slate-700',
    dot: 'bg-slate-500',
  };

  return (
    <div className="group bg-white rounded-2xl border border-slate-100 p-6 shadow-sm hover:shadow-md hover:border-slate-200 transition-all duration-300 flex flex-col justify-between h-48 relative overflow-hidden">
      {/* Background visual highlight */}
      <div className="absolute top-0 right-0 w-32 h-32 bg-slate-50 rounded-bl-full -mr-16 -mt-16 group-hover:scale-110 transition-transform duration-300 opacity-60 pointer-events-none" />

      <div className="relative z-10">
        <div className="flex items-center space-x-4 mb-3">
          {/* Avatar */}
          <div className="w-12 h-12 rounded-full bg-gradient-to-tr from-indigo-50 to-slate-100 flex items-center justify-center border border-indigo-100 group-hover:scale-105 transition-transform duration-300">
            <span className="text-sm font-bold text-indigo-600 tracking-wider">
              {getInitials(employee.name)}
            </span>
          </div>

          <div className="flex-1 min-w-0">
            <h4 className="text-base font-bold text-slate-800 truncate leading-snug group-hover:text-indigo-600 transition-colors">
              <SearchHighlight text={employee.name} highlight={searchTerm} />
            </h4>
            <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider truncate">
              {employee.designation}
            </p>
          </div>
        </div>

        {/* Email */}
        <div className="flex items-center space-x-2 text-slate-500 text-xs mb-2 truncate">
          <svg className="w-4 h-4 text-slate-400 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
          </svg>
          <span className="truncate">{employee.email}</span>
        </div>
      </div>

      {/* Footer info: Joining Date & Dept Tag */}
      <div className="relative z-10 flex justify-between items-center mt-3 pt-3 border-t border-slate-50">
        <div className="text-[11px] text-slate-400 flex flex-col">
          <span>Joined On</span>
          <span className="font-semibold text-slate-600 mt-0.5">{formatDate(employee.date_of_joining)}</span>
        </div>

        <span className={`inline-flex items-center space-x-1.5 px-2.5 py-1 rounded-full text-[10px] font-bold tracking-wider uppercase ${colors.bg} ${colors.text} border border-slate-100`}>
          <span className={`w-1.5 h-1.5 rounded-full ${colors.dot}`} />
          <span>
            <SearchHighlight text={employee.department} highlight={searchTerm} />
          </span>
        </span>
      </div>
    </div>
  );
};
