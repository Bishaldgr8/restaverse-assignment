import React from 'react';

interface LoaderProps {
  count?: number;
}

export const Loader: React.FC<LoaderProps> = ({ count = 6 }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {Array.from({ length: count }).map((_, index) => (
        <div
          key={index}
          className="bg-white rounded-2xl border border-slate-100 p-6 shadow-sm flex flex-col justify-between h-48 animate-skeleton-pulse"
        >
          <div>
            {/* Header info */}
            <div className="flex items-center space-x-4 mb-4">
              <div className="w-12 h-12 bg-slate-200 rounded-full"></div>
              <div className="flex-1 space-y-2">
                <div className="h-4 bg-slate-200 rounded w-3/4"></div>
                <div className="h-3 bg-slate-200 rounded w-1/2"></div>
              </div>
            </div>

            {/* Email and dept */}
            <div className="space-y-2">
              <div className="h-3 bg-slate-200 rounded w-5/6"></div>
              <div className="h-3 bg-slate-200 rounded w-2/3"></div>
            </div>
          </div>

          {/* Footer date */}
          <div className="flex justify-between items-center mt-4 pt-4 border-t border-slate-50">
            <div className="h-3 bg-slate-200 rounded w-1/3"></div>
            <div className="h-6 bg-slate-200 rounded-full w-20"></div>
          </div>
        </div>
      ))}
    </div>
  );
};
