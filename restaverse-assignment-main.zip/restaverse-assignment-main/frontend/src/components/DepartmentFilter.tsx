import React from 'react';
import { useDepartments } from '../hooks/useDepartments';

interface DepartmentFilterProps {
  selectedDepartment: string;
  onChange: (department: string) => void;
}

export const DepartmentFilter: React.FC<DepartmentFilterProps> = ({
  selectedDepartment,
  onChange,
}) => {
  const { departments, isLoading } = useDepartments();

  return (
    <div className="relative w-full sm:w-64">
      <select
        value={selectedDepartment}
        onChange={(e) => onChange(e.target.value)}
        disabled={isLoading}
        className="block w-full px-4 py-3.5 pr-10 border border-slate-200 rounded-2xl bg-white text-slate-700 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 hover:border-slate-300 transition-all cursor-pointer shadow-sm appearance-none"
      >
        <option value="">All Departments</option>
        {departments.map((dept) => (
          <option key={dept} value={dept}>
            {dept}
          </option>
        ))}
      </select>
      {/* Custom dropdown arrow */}
      <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-4 text-slate-400">
        <svg
          className="w-4 h-4"
          fill="none"
          stroke="currentColor"
          viewBox="0 0 24 24"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth="2"
            d="M19 9l-7 7-7-7"
          />
        </svg>
      </div>
    </div>
  );
};
