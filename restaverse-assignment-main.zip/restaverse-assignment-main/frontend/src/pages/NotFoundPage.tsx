import React from 'react';
import { Link } from 'react-router-dom';

export const NotFoundPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-slate-50 flex flex-col justify-center items-center px-6 py-12 text-center">
      <div className="max-w-md w-full bg-white rounded-3xl border border-slate-100 p-8 md:p-12 shadow-lg flex flex-col items-center">
        {/* Animated 404 Visual */}
        <div className="relative w-36 h-36 mb-6">
          <div className="absolute inset-0 bg-indigo-50 rounded-full animate-pulse" />
          <div className="absolute inset-0 flex items-center justify-center text-5xl font-extrabold text-indigo-600 tracking-wider">
            404
          </div>
        </div>

        <h2 className="text-2xl font-bold text-slate-800 tracking-tight mb-2">Page Not Found</h2>
        <p className="text-slate-500 text-sm mb-8 leading-relaxed">
          The page you are looking for doesn't exist or has been moved to another location.
        </p>

        <Link
          to="/"
          className="inline-flex items-center justify-center px-6 py-3 border border-transparent text-sm font-semibold rounded-2xl text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-all shadow-md shadow-indigo-100 hover:shadow-lg active:scale-95 w-full"
        >
          Back to Directory
        </Link>
      </div>
    </div>
  );
};
