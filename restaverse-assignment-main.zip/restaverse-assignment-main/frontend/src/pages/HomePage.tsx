import React, { useState } from 'react';
import { Layout } from '../components/Layout';
import { SearchBar } from '../components/SearchBar';
import { DepartmentFilter } from '../components/DepartmentFilter';
import { SortControls } from '../components/SortControls';
import { EmployeeList } from '../components/EmployeeList';
import { Pagination } from '../components/Pagination';
import { Loader } from '../components/Loader';
import { EmptyState } from '../components/EmptyState';
import { ErrorState } from '../components/ErrorState';
import { useEmployees } from '../hooks/useEmployees';
import { useDebounce } from '../hooks/useDebounce';
import { SortField, SortOrder } from '../types';
import { DEFAULTS } from '../constants';

export const HomePage: React.FC = () => {
  // ─── Search & Filter States ───────────────────────────────────────────────
  const [search, setSearch] = useState('');
  const [department, setDepartment] = useState('');
  const [sortBy, setSortBy] = useState<SortField>(DEFAULTS.SORT_BY);
  const [sortOrder, setSortOrder] = useState<SortOrder>(DEFAULTS.SORT_ORDER);
  const [page, setPage] = useState(DEFAULTS.PAGE);

  // Debounce search query by 500ms
  const debouncedSearch = useDebounce(search, 500);

  // Fetch employees data using custom hook with debounced search term
  const {
    employees,
    pagination,
    isLoading,
    isError,
    error,
    refetch,
  } = useEmployees({
    search: debouncedSearch,
    department,
    page,
    limit: DEFAULTS.LIMIT,
    sort_by: sortBy,
    sort_order: sortOrder,
  });

  // ─── Event Handlers ────────────────────────────────────────────────────────
  const handleSearchChange = (val: string) => {
    setSearch(val);
    setPage(1); // Reset to first page on search input
  };

  const handleDepartmentChange = (val: string) => {
    setDepartment(val);
    setPage(1); // Reset to first page on filter input
  };

  const handleSortByChange = (field: SortField) => {
    setSortBy(field);
    setPage(1);
  };

  const handleSortOrderToggle = () => {
    setSortOrder((prev) => (prev === 'asc' ? 'desc' : 'asc'));
    setPage(1);
  };

  const handlePageChange = (newPage: number) => {
    setPage(newPage);
  };

  const handleResetFilters = () => {
    setSearch('');
    setDepartment('');
    setSortBy(DEFAULTS.SORT_BY);
    setSortOrder(DEFAULTS.SORT_ORDER);
    setPage(DEFAULTS.PAGE);
  };

  // Determine if filters are active
  const isFiltered = search !== '' || department !== '' || sortBy !== DEFAULTS.SORT_BY || sortOrder !== DEFAULTS.SORT_ORDER;

  return (
    <Layout>
      <div className="flex flex-col space-y-8">
        {/* Page title and description */}
        <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-4">
          <div>
            <h2 className="text-2xl font-extrabold text-slate-800 tracking-tight md:text-3xl">
              Employee Directory
            </h2>
            <p className="text-slate-500 text-sm mt-1 leading-relaxed">
              Manage, search, and filter company directory information instantly.
            </p>
          </div>
          
          {/* Reset Filters Shortcut */}
          {isFiltered && (
            <button
              onClick={handleResetFilters}
              className="inline-flex items-center justify-center px-4 py-2 border border-slate-200 hover:border-slate-300 text-xs font-bold rounded-xl text-slate-700 bg-white hover:bg-slate-50 transition-all active:scale-95 shadow-sm"
            >
              Reset Filters
            </button>
          )}
        </div>

        {/* Search & Filter Toolbar */}
        <div className="bg-white rounded-2xl border border-slate-100 p-4 shadow-sm flex flex-col md:flex-row md:items-center gap-4 z-30">
          <SearchBar
            value={search}
            onChange={handleSearchChange}
            onSearchSubmit={handleSearchChange}
          />
          <div className="flex flex-col sm:flex-row items-center gap-4 w-full md:w-auto">
            <DepartmentFilter
              selectedDepartment={department}
              onChange={handleDepartmentChange}
            />
            <SortControls
              sortBy={sortBy}
              sortOrder={sortOrder}
              onSortByChange={handleSortByChange}
              onSortOrderToggle={handleSortOrderToggle}
            />
          </div>
        </div>

        {/* Content Area (States: Error, Loading, Empty, Data list) */}
        {isError ? (
          <ErrorState
            message={error?.message}
            onRetry={refetch}
          />
        ) : isLoading ? (
          <div className="space-y-6">
            <div className="h-6 w-48 bg-slate-200 rounded animate-pulse"></div>
            <Loader count={DEFAULTS.LIMIT} />
          </div>
        ) : employees.length === 0 ? (
          <EmptyState onReset={handleResetFilters} />
        ) : (
          <div className="flex flex-col space-y-6">
            {/* List count summary */}
            <div className="flex justify-between items-center text-sm">
              <span className="text-slate-500 font-medium">
                Showing{' '}
                <span className="font-bold text-slate-800">
                  {employees.length}
                </span>{' '}
                employee(s)
              </span>
            </div>

            {/* Grid list of employees */}
            <EmployeeList employees={employees} searchTerm={debouncedSearch} />

            {/* Pagination Controls */}
            <Pagination meta={pagination} onPageChange={handlePageChange} />
          </div>
        )}
      </div>
    </Layout>
  );
};
