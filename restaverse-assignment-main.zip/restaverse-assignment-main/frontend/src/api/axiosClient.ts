import axios from 'axios';
import { API_BASE_URL } from '../constants';

const axiosClient = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
  timeout: 10000, // 10 seconds timeout
});

// Interceptor to format error responses consistently
axiosClient.interceptors.response.use(
  (response) => response,
  (error) => {
    const message =
      error.response?.data?.message ||
      error.message ||
      'An unexpected network error occurred';
    
    // Normalize error format
    return Promise.reject({
      success: false,
      message,
      data: null,
    });
  }
);

export default axiosClient;
